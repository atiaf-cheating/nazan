<?php
return [
'facebook' => env('FACEBOOK_LINK', 'www.facebook.com'),
'twitter' => env('TWITTER_LINK', 'www.twitter.com'),
'instagram' => env('INSTAGRAM_LINK', 'www.instagram.com'),
'youtube' => env('YOUTUBE_LINK', 'www.youtube.com'),
'google' => env('GOOGLE_LINK', 'www.google.com'),
];
