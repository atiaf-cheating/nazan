<?php $__env->startSection('content'); ?>
    <?php
        $language = App::getLocale();
    ?>
    <div class="row <?php if($language == 'ar'): ?> rtl <?php endif; ?> " style=" margin-top: 2%; margin-left: 2%;;padding:0;">
        <div class="col">
            <h2 style="color:#007BFF;"><?php echo e($product_name); ?></h2>
            <h4><i class="fa fa-plus <?php if($language == 'ar'): ?> rtl <?php endif; ?>"
                                             style="background: #74777a;border-radius: 500%;font-size: 1.1rem;padding: 6px;color: #EEE;position: relative;top: -2px;"></i>
                &nbsp;<?php echo app('translator')->get('messages.create new color/size'); ?>
            </h4>
        </div>
    </div>
    <?php if($errors->any()): ?>
        <div class="alert alert-danger <?php if($language == 'ar'): ?> rtl <?php endif; ?>" style="width: 90%;margin-left: 2%;">
            <ul class=" <?php if($language == 'ar'): ?> rtl <?php endif; ?>">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class=" <?php if($language == 'ar'): ?> rtl <?php endif; ?>"><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <form method="post" action="<?php echo e(route('product_color_size.store')); ?>" id="color_size_form" enctype="multipart/form-data" class=" <?php if($language == 'ar'): ?> rtl <?php endif; ?>"
          style="width: 90%;border-top: 4px solid #007BFF;border-bottom: 4px solid #007BFF; padding: 3%; margin: 2%;background: white;">
        <?php echo e(csrf_field()); ?>

        <input name="product_id" value="<?php echo e($product_id); ?>" hidden>
        <input name="number_of_sizes" value="<?php echo e(count($sizes)); ?>" hidden>
        <input name="cat_id" value="<?php echo e($cat_id); ?>" hidden>
        <div class="form-group row  <?php if($language == 'ar'): ?> rtl <?php endif; ?>">
            <div class="col-md-7">
                <label for="parent_cat" class=" <?php if($language == 'ar'): ?> rtl <?php endif; ?>"><?php echo app('translator')->get('messages.select color'); ?></label>
                <select  name="color" class="browser-default custom-select">
                    <?php $__currentLoopData = $colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($color->id); ?>"><?php echo e($color->arabic_name .'-'. $color->english_name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-md-5">
                <label for="parent_cat" class=" <?php if($language == 'ar'): ?> rtl <?php endif; ?>"><?php echo app('translator')->get('messages.order'); ?></label>
                <input id="size_input" name="color_order" class="form-control" type="text" class="" value="">
            </div>
        </div>
        <hr>
        <?php $__currentLoopData = $sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="row">
                <div class="form-group col-md-4 form-inline <?php if($language == 'ar'): ?> rtl <?php endif; ?>">
                    <input id="size_input" name="size_id_<?php echo e($key); ?>" type="checkbox" class="" value="<?php echo e($size->id); ?>">
                    <label for="size_input" class=" <?php if($language == 'ar'): ?> rtl <?php endif; ?>"><?php echo e($size->arabic_name .'-'. $size->english_name); ?></label>
                </div>
                <div class="form-inline col-md-8">
                    <div class="form-group   <?php if($language == 'ar'): ?> rtl <?php endif; ?>">
                        <label for="size_input" class=" <?php if($language == 'ar'): ?> rtl <?php endif; ?>"><?php echo app('translator')->get('messages.price'); ?></label>
                        <input type="text" name="price_<?php echo e($key); ?>">
                    </div>
                    <div class="form-group  <?php if($language == 'ar'): ?> rtl <?php endif; ?>">
                        <label for="size_input" class=" <?php if($language == 'ar'): ?> rtl <?php endif; ?>"><?php echo app('translator')->get('messages.order'); ?></label>
                        <input type="text" name="order_<?php echo e($key); ?>">
                    </div>
                    <div class="form-group  <?php if($language == 'ar'): ?> rtl <?php endif; ?>">
                        <label for="size_input" class=" <?php if($language == 'ar'): ?> rtl <?php endif; ?>"><?php echo app('translator')->get('messages.quantity'); ?></label>
                        <input type="text" name="quantity_<?php echo e($key); ?>">
                    </div>
                    <div class="form-group  <?php if($language == 'ar'): ?> rtl <?php endif; ?>">
                        <label for="discount_input" class=" <?php if($language == 'ar'): ?> rtl <?php endif; ?>"><?php echo app('translator')->get('messages.discount'); ?></label>
                        <input type="text" name="discount_<?php echo e($key); ?>">
                    </div>
                </div>
            </div>
            <br><hr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <button type="submit" class="btn btn-primary <?php if($language == 'ar'): ?> rtl <?php endif; ?>" style="float:right;"><?php echo app('translator')->get('messages.add'); ?></button><br>
    </form>
    <table class="table table-bordered products-table <?php if($language == 'ar'): ?> rtl <?php endif; ?>" style=" margin-top: 2%; margin-left: 2%;width:90%;" id="table">
        <thead class="thead-light">
        <tr class=" <?php if($language == 'ar'): ?> rtl <?php endif; ?>">
            <th class=" <?php if($language == 'ar'): ?> rtl <?php endif; ?>"><?php echo app('translator')->get('messages.color'); ?></th>
            <th class=" <?php if($language == 'ar'): ?> rtl <?php endif; ?>"><?php echo app('translator')->get('messages.order'); ?></th>
            <th class=" <?php if($language == 'ar'): ?> rtl <?php endif; ?>"><?php echo app('translator')->get('messages.actions'); ?></th>
        </tr>
        </thead>
        <tbody class=" <?php if($language == 'ar'): ?> rtl <?php endif; ?>">
        <?php $__currentLoopData = $color_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $color_product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <tr id="<?php echo e($key); ?>" class=" <?php if($language == 'ar'): ?> rtl <?php endif; ?>">
                <th class=" <?php if($language == 'ar'): ?> rtl <?php endif; ?>"> <?php echo e($color_product->colors->arabic_name .'-'.$color_product->colors->english_name); ?></th>
                <th class=" <?php if($language == 'ar'): ?> rtl <?php endif; ?>"><?php echo e($color_product->order); ?></th>
                <th class=" <?php if($language == 'ar'): ?> rtl <?php endif; ?>">
                    <a href="<?php echo e(url('color_size/edit/'.$product_id.'/'.$color_product->id.'/'.$cat_id)); ?>" class="btn btn-info <?php if($language == 'ar'): ?> rtl <?php endif; ?>"><?php echo app('translator')->get('messages.edit'); ?></a>
                    <a href="<?php echo e(url('color_size/activate/'.$color_product->id)); ?>" class="btn btn-warning <?php if($language == 'ar'): ?> rtl <?php endif; ?>">
                        <?php if($color_product->active == 0): ?>
                            <?php echo app('translator')->get('messages.activate'); ?>
                        <?php else: ?> <?php echo app('translator')->get('messages.deactivate'); ?> <?php endif; ?>
                    </a>
                    <a href="<?php echo e(url('color_size/delete/'.$color_product->id)); ?>" onclick="return confirm('Are you sure?')" class="btn btn-danger <?php if($language == 'ar'): ?> rtl <?php endif; ?>"><?php echo app('translator')->get('messages.delete'); ?></a>
                    <button href="#" data-id="<?php echo e($color_product->id); ?>" id="sizes_<?php echo e($key); ?>" data_key="<?php echo e($key); ?>" onclick="showSizes(<?php echo e($key); ?>)" class="btn btn-success <?php if($language == 'ar'): ?> rtl <?php endif; ?>"><?php echo app('translator')->get('messages.sizes'); ?></button>
                </th>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php echo e($color_products->links()); ?>

    <script src="https://code.jquery.com/jquery-3.5.0.min.js" integrity="sha256-xNzN2a4ltkB44Mc/Jz3pT4iU1cmeR0FkXs4pru/JxaQ=" crossorigin="anonymous"></script>

    <script>
        function showSizes(key) {
            if($('.sizesDetailedTable_'+key).length === 0){
                $id = $("#sizes_"+key).attr("data-id");
                $.ajax({
                    method: "get",
                    url: "/color_size/sizes/" + $id,
                    data: {
                        id: $id,
                        "_token": "<?php echo e(csrf_token()); ?>"
                    }
                }).done(function ($data) {
                    if (Object.keys($data).length !== 0) {
                        $sizesTable = `<table class="table table-bordered sizesDetailedTable_${key}" style=" margin-top: 2%; margin-left: 2%;width:90%;" id="table">` +
                            `<thead class="thead-light">` +
                            `<tr><th><?php echo app('translator')->get('messages.size'); ?></th>
                                    <th><?php echo app('translator')->get('messages.price'); ?></th>
                                    <th><?php echo app('translator')->get('messages.quantity'); ?></th>
                                    <th><?php echo app('translator')->get('messages.order'); ?></th>
                                    <th><?php echo app('translator')->get('messages.discount'); ?></th>
                                    <th><?php echo app('translator')->get('messages.actions'); ?></th>
                        </tr> </thead> <tbody class="sizes_tbody">`;
                        $("#" + key).after($sizesTable);

                        $.each($data, function (sizes_key, value) {
                            console.log('fffffff',value.active);
                            $is_active = 'activate';
                            if(value.active == 0){
                                $is_active = 'activate';
                            }else{
                                $is_active = 'deactivate';
                            }
                            $is_active =
                            $tbodyData = ` <tr id="detailsRow_${sizes_key}"><th>${value.sizes.arabic_name}-${value.sizes.english_name}</th>
                                            <th class="priceBox_${sizes_key}">${value.price}</th>
                                            <th class="quantityBox_${sizes_key}">${value.quantity}</th>
                                            <th>${value['order']}</th>
                                            <th class="discountBox_${sizes_key}">${value.discount}</th>

                                            <th>
                                                <button data-sizeId="${value.size_id}" data-price="${value.price}" data-quantity="${value.quantity}" data-discount="${value.discount}"  onclick="editSizeFunction(${sizes_key},${value.id},${value.size_id},${value.price},${value.quantity},${value.discount})" id="edit_size_${sizes_key}" data-color-size-id="${value.id}" class="btn btn-info"><?php echo app('translator')->get('messages.edit'); ?></button>
                                                <button onclick="deactivateSizeFunction(${sizes_key},${value.id})" id="deactivate_size_${sizes_key}" data-color-size-id="${value.id}" class="btn btn-warning activate-btn_${value.id}"> ${$is_active} </button>
                                                <button  onclick="deleteSizeFunction(${sizes_key},${value.id})" id="delete_size_${value.id}" data-color-size-id="${value.id}" class="btn btn-danger "><?php echo app('translator')->get('messages.delete'); ?></button>
                                            </th>
                                        </tr>`;
                            // $option = `<option class="sub_cat_option" value="${value.id}">${value.arabic_name} - ${value.english_name}</option>`;
                            $(".sizesDetailedTable_"+key).children('.sizes_tbody').append($tbodyData);

                            console.log(key + ": " + value.arabic_name);
                        });
                    }
                }).fail(function () {
                    alert("error");
                })
            }else {
                $('.sizesDetailedTable_'+key).css('display','none');
            }
        }
        function deleteSizeFunction(btnKey , color_size_id) {
            console.log('eeeeeeeeeeeeeeeeee');
            $.ajax({
                method: "post",
                url: "/color_size/delete-price-quantity",
                data: {
                    "id": color_size_id,
                    "_token": "<?php echo e(csrf_token()); ?>"
                }
            }).done(function ($data) {
                console.log($data);
                $("#detailsRow_"+btnKey).css('display','none');
            }).fail(function () {
                alert("error");
            })
        }
        function editSizeFunction( btnKey , color_size_id , sizeId ,price ,quantity,discount) {
            $editRow = `<br> <div class="row">&nbsp;&nbsp;&nbsp;
                    <label for="size_input" class="col ">size : ${sizeId}</label>&nbsp;
                        <label for="size_input" class="col"><?php echo app('translator')->get('messages.price'); ?></label>&nbsp;
                        <input id="newPrice_${btnKey}" type="text"  class="col form-control" value="${price}">&nbsp;
                        <label  for="size_input" class="col "><?php echo app('translator')->get('messages.quantity'); ?></label>&nbsp;
                        <input id="newQuantity_${btnKey}" type="text"  class="col form-control" value="${quantity}">&nbsp;
                        <label  for="size_input" class="col "><?php echo app('translator')->get('messages.discount'); ?></label>&nbsp;
                        <input id="newDiscount_${btnKey}" type="text"  class="col form-control" value="${discount}">&nbsp;
                        <button  class="btn btn-success col" onclick="storeSizeDataFunction(${btnKey},${color_size_id},${price},${quantity},${discount})" value="">save</button>
            </div>`;
            $("#detailsRow_"+btnKey).after($editRow);
        }
        function storeSizeDataFunction(btnKey ,color_size_id,price,quantity,discount) {
            $.ajax({
                method: "post",
                url: "/color_size/edit-price-quantity",
                data: {
                    "id": color_size_id,
                    "price": $("#newPrice_"+btnKey).val(),
                    "quantity": $("#newQuantity_"+btnKey).val(),
                    "discount": $("#newDiscount_"+btnKey).val(),
                    "_token": "<?php echo e(csrf_token()); ?>"
                }
            }).done(function ($data) {
                $(".priceBox_"+btnKey).html($data.price);
                $(".quantityBox_"+btnKey).html($data.quantity);
                $(".discountBox_"+btnKey).html($data.discount);
            }).fail(function () {
                alert("error");
            })
        }
        function deactivateSizeFunction(btnKey , color_size_id) {
            $.ajax({
                method: "post",
                url: "/color_size/deactivate-price-quantity",
                data: {
                    "id": color_size_id,
                    "_token": "<?php echo e(csrf_token()); ?>"
                }
            }).done(function ($data) {
                console.log($data);
                if($data == 0){
                    $isActive = 'activate';
                }else{
                    $isActive = 'deactivate';
                }
                // $("#detailsRow_"+btnKey).css('display','none');
                $('.activate-btn_'+color_size_id).text($isActive);
            }).fail(function () {
                alert("error");
            })
        }

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('no-sidebar-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nazan-v6last\nazan-v6\resources\views/color-size/create.blade.php ENDPATH**/ ?>