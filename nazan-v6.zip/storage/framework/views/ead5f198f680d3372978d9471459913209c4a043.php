

<!DOCTYPE html>
<html lang="en">
    <?php
        $language = App::getLocale();
    ?>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->

    <title><?php echo app('translator')->get('messages.NAZAN | Home'); ?></title>

    <!-- Google font -->
    <link href="https://fonts.googleapis.com/css?family=Hind:400,700" rel="stylesheet">
    <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(asset("img/favicon.png")); ?>"/>
    <!-- Bootstrap -->
    <link type="text/css" rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>"/>

    <!-- Slick -->
    <link type="text/css" rel="stylesheet" href="<?php echo e(asset('css/slick.css')); ?>" />
    <link type="text/css" rel="stylesheet" href="<?php echo e(asset('css/slick-theme.css')); ?>" />

    <!-- nouislider -->
    <link type="text/css" rel="stylesheet" href="<?php echo e(asset('css/nouislider.min.css')); ?>"/>

    <!-- Font Awesome Icon -->
    <link href="//maxcdn.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.min.css" rel="stylesheet">

    <link rel="stylesheet"  href="<?php echo e(asset('css/font-awesome.min.css')); ?>"/>

    <!-- Custom stlylesheet -->
    <?php if($language == 'en'): ?>
        <link type="text/css" rel="stylesheet"href="<?php echo e(asset('css/style.css')); ?>" />
    <?php else: ?>
        <link type="text/css" rel="stylesheet"href="<?php echo e(asset('css/style-ar.css')); ?>" />
    <?php endif; ?>

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>
<!-- HEADER -->
<header>

    <div id="top-header">
        <div class="container">
            <div class="pull-left">
                <span><?php echo app('translator')->get('messages.free shipping on all domestic orders above 45.00 omr'); ?></span>
            </div>
            <div class="pull-right">
                <ul class="header-top-links">
                    
                    <li class="nav-item dropdown" style="list-style: none;">
                        <?php if($language == 'ar'): ?>
                            <a class="dropdown-item" href="<?php echo e(route('/en',['lang'=>'en'])); ?>">
                                <?php echo app('translator')->get('messages.english'); ?>
                            </a>
                        <?php else: ?>
                            <a class="dropdown-item" href="<?php echo e(route('/ar',['lang'=>'ar'])); ?>">
                                <?php echo app('translator')->get('messages.arabic'); ?>
                            </a>
                        <?php endif; ?>
                        
                        
                        

                        
                        
                        
                        
                        
                        
                        

                        
                    </li>
                </ul>
            </div>
        </div>
    </div>

    <!-- header -->
    <div id="header">
        <div class="container">
            <div class="pull-left">
                <!-- Logo -->
                <div class="header-logo">
                    <a class="logo" href="<?php echo e(url('/customer/home')); ?>">
                        <img src="<?php echo e(asset('img/logo.png')); ?>" alt="">
                    </a>
                </div>
            </div>
            <div class="pull-right">
                <ul class="header-btns">
                    <!-- Account -->
                    <li class="header-account dropdown default-dropdown">
                        <div>
                            <div class="header-btns-icon">
                                <i class="fa fa-user"></i>
                            </div>
                            <a href="<?php echo e(url('customer/profile')); ?>"><strong class="text-uppercase"><?php echo app('translator')->get('messages.My Account'); ?></strong></a>
                        </div>
                        <?php if(!session()->has('customer')): ?>
                            <a href="<?php echo e(url('customer/register')); ?>" class=""><?php echo app('translator')->get('messages.register'); ?></a>
                            <span class="white">/</span>
                            <a href="<?php echo e(url('login/customer')); ?>" class=""><?php echo app('translator')->get('messages.Sign in'); ?></a>
                        <?php else: ?>

                            <a href="<?php echo e(url('logout/customer')); ?>" class="">Logout</a>
                        <?php endif; ?>
                    </li>
                    <!-- /Account -->

                    <!-- Cart -->
                    <?php
                        if(session()->has('cart')){
                            $cart = session()->get('cart');
                        }
                    ?>
                    <li class="header-cart dropdown default-dropdown" >
                        <a class="dropdown-toggle" data-toggle="dropdown" id="dropdownMenuButton">
                            <div class="header-btns-icon">
                                <i class="fa fa-shopping-cart"></i>
                                <span class="qty">
                                    <?php if(isset($cart)): ?>
                                        <?php echo e(count($cart->products)); ?>

                                    <?php else: ?>
                                        0
                                    <?php endif; ?>
                                </span>
                            </div>
                            <strong class="text-uppercase"><?php echo app('translator')->get('messages.My cart'); ?>:</strong>
                            <br>
                            <span>
                                 <?php if(isset($cart) && isset($cart->totalPrice)): ?>
                                    $<?php echo e($cart->totalPrice); ?>

                                <?php endif; ?>
                            </span>
                        </a>
                        <div class="dropdown-menu"  aria-labelledby="dropdownMenuButton">
                            <?php if(isset($cart)): ?>
                                <?php $__currentLoopData = $cart->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <div class="product product-widget">
                                        <div class="product-thumb">
                                            <img src="<?php echo e(asset('images/products/'.$product['image_url'])); ?>" alt="">
                                        </div>
                                        <div class="product-body">
                                            <h3 class="product-price">$<?php if($product['discount'] == null): ?> <?php echo e($product['price']); ?> <?php else: ?> <?php echo e($product['price'] - $product['price']*$product['discount']/100); ?> <?php endif; ?> <span class="qty">x <?php if(array_key_exists('quantity',$product)): ?> <?php echo e($product['quantity']); ?> <?php else: ?> 1 <?php endif; ?></span></h3>
                                            <h2 class="product-name"><a href="<?php echo e(url('customer/product/details/'.$product['id'])); ?>"><?php echo e($product['english_name']); ?> - <?php echo e($product['arabic_name']); ?></a></h2>
                                        </div>
                                        <form method="post" action="<?php echo e(url('customer/remove_from_cart')); ?>">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" name="product_id" value="<?php echo e($product['id']); ?>">
                                            <button type="submit" class="cancel-btn"><i class="fa fa-close"></i></button>
                                        </form>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                            <a href="<?php echo e(url('customer/cart_details')); ?>" class="main-btn"><?php echo app('translator')->get('messages.View Cart'); ?></a>
                                <?php if(isset($cart) && count($cart->products)> 0): ?>
                                    <a href="<?php echo e(url('customer/checkout')); ?>" class="btn primary-btn"><?php echo app('translator')->get('messages.Check Out'); ?><i class="fa fa-arrow-circle-right"></i></a>
                                <?php else: ?>
                                    <a href="#" class="btn primary-btn" disabled="true"><?php echo app('translator')->get('messages.Check Out'); ?><i class="fa fa-arrow-circle-right"></i></a>
                                <?php endif; ?>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
        <!-- header -->
    </div>
    <!-- container -->
</header>
<!-- /HEADER -->
<?php /**PATH C:\xampp\htdocs\nazan-v6last\nazan-v6\resources\views/customer/header.blade.php ENDPATH**/ ?>