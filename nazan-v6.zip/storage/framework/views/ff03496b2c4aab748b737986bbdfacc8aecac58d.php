<?php $__env->startSection('content'); ?>
    <?php
        $language = App::getLocale();
        if(isset($parent_cat_id)){
            $parent_id = $parent_cat_id;
        }else{
            $parent_id = 0;
        }
    ?>
        <div class="row <?php if($language == 'ar'): ?> rtl <?php endif; ?>" style=" margin-top: 2%; margin-left: 2%;;padding:0;">
            <div class="col <?php if($language == 'ar'): ?> rtl <?php endif; ?>">
                <h2 class=" <?php if($language == 'ar'): ?> rtl <?php endif; ?>"><?php echo app('translator')->get('messages.categories'); ?></h2>
            </div>
            <?php if($cat_id == 0): ?>
                <div class="col  <?php if($language == 'ar'): ?> rtl <?php endif; ?>" style="float:right;padding:0;">
                    <a class="btn btn-success <?php if($language == 'ar'): ?> rtl <?php endif; ?>" href="<?php echo e(url('categories/create/'.$parent_id)); ?>"> <?php echo app('translator')->get('messages.add new'); ?></a>
                </div>
                <?php endif; ?>

        </div>

        <table class="table table-bordered categories-table <?php if($language == 'ar'): ?> rtl <?php endif; ?>" style=" margin-top: 2%; margin-left: 2%;width:90%;" id="table">
            <thead>
            <tr class=" <?php if($language == 'ar'): ?> rtl <?php endif; ?>">
                <th class=" <?php if($language == 'ar'): ?> rtl <?php endif; ?>"><?php echo app('translator')->get('messages.arabic name'); ?></th>
                <th class=" <?php if($language == 'ar'): ?> rtl <?php endif; ?>"><?php echo app('translator')->get('messages.english name'); ?></th>
                <th class=" <?php if($language == 'ar'): ?> rtl <?php endif; ?>"><?php echo app('translator')->get('messages.photo'); ?></th>
                <th class=" <?php if($language == 'ar'): ?> rtl <?php endif; ?>"><?php echo app('translator')->get('messages.order'); ?></th>
                <th class=" <?php if($language == 'ar'): ?> rtl <?php endif; ?>"><?php echo app('translator')->get('messages.actions'); ?></th>
            </tr>

            </thead>
            <tbody class=" <?php if($language == 'ar'): ?> rtl <?php endif; ?>">
            <?php if(count($categories) == 0): ?>
            <?php endif; ?>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class=" <?php if($language == 'ar'): ?> rtl <?php endif; ?>">
                    <th class=" <?php if($language == 'ar'): ?> rtl <?php endif; ?>"> <?php echo e($category->arabic_name); ?></th>
                    <th class=" <?php if($language == 'ar'): ?> rtl <?php endif; ?>"><?php echo e($category->english_name); ?></th>
                    <th class=" <?php if($language == 'ar'): ?> rtl <?php endif; ?>" style="width: 6%; height: 6%;">
                        <img src=" <?php echo e(asset("images/categories/".$category->image_url)); ?>" style="width: 100%;">
                    </th>
                    <th class=" <?php if($language == 'ar'): ?> rtl <?php endif; ?>"><?php echo e($category->order); ?></th>
                    <th class=" <?php if($language == 'ar'): ?> rtl <?php endif; ?>">
                        <a href="<?php echo e(url('/categories/'.$category->id)); ?>" class="btn btn-success <?php if($language == 'ar'): ?> rtl <?php endif; ?>"><?php echo app('translator')->get('messages.sub categories'); ?></a>
                        <a href="<?php echo e(url('categories/edit/'.$category->id)); ?>" class="btn btn-info <?php if($language == 'ar'): ?> rtl <?php endif; ?>"><?php echo app('translator')->get('messages.edit'); ?></a>
                        <a href="<?php echo e(url('categories/activate/'.$category->id)); ?>" class="btn btn-warning <?php if($language == 'ar'): ?> rtl <?php endif; ?>"><?php if($category->active == 0): ?> <?php echo app('translator')->get('messages.activate'); ?> <?php else: ?> <?php echo app('translator')->get('messages.deactivate'); ?> <?php endif; ?></a>
                        <a href="<?php echo e(url('categories/delete/'.$category->id)); ?>" onclick="return confirm('Are you sure?')" class="btn btn-danger <?php if($language == 'ar'): ?> rtl <?php endif; ?>"><?php echo app('translator')->get('messages.delete'); ?></a>
                        <a href="<?php echo e(url('categories/create/'.$category->id)); ?>" class="btn btn-dark <?php if($language == 'ar'): ?> rtl <?php endif; ?>"><?php echo app('translator')->get('messages.add sub category'); ?></a>
                        <a id="sizes_btn" onclick="window.open(document.URL.substring(0, document.URL.indexOf('categories'))+ 'sizes/' + <?php echo e($category->id); ?>, '_blank',
                            'location=yes,top=50,left=200,height=850,width=1500,scrollbars=yes,status=yes');"
                            class="btn btn-primary <?php if($language == 'ar'): ?> rtl <?php endif; ?>"><?php echo app('translator')->get('messages.sizes'); ?></a>

                    </th>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <?php echo e($categories->links()); ?>

    <script>
        document.getElementById("sizes_btn").addEventListener("click", function(event){
            event.preventDefault();
        });
        document.getElementById("sizes_btn").addEventListener("click", function(event){
            event.preventDefault();
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('categories.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nazan-v6last\nazan-v6\resources\views/categories/index.blade.php ENDPATH**/ ?>