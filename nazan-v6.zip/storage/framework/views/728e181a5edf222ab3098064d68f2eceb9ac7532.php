
<!-- FOOTER -->
<footer  class="section" id="footer">
    <!-- container -->
    <div class="container">
        <!-- row -->
        <div class="row">
            <!-- footer widget -->
            <div class="col-md-3 col-sm-6 col-xs-6">
                <div class="footer">
                    <!-- footer logo -->
                    <div class="footer-logo">
                        <a class="logo" href="index.php">
                            <img src="<?php echo e(asset('img/logo.png')); ?>" alt="">
                        </a>
                    </div>
                    <!-- /footer logo -->
                    <!-- footer social -->
                    <ul class="footer-social">
                        <li><a href="<?php echo e($about->facebook_url); ?>"><i class="fa fa-facebook"></i></a></li>
                        <li><a href="<?php echo e($about->twitter_url); ?>"><i class="fa fa-twitter"></i></a></li>
                        <li><a href="<?php echo e($about->instagram_url); ?>"><i class="fa fa-instagram"></i></a></li>
                        <li><a href="<?php echo e($about->email); ?>"><i class="fa fa-google-plus"></i></a></li>
                        <li><a href="#"><i class="fa fa-youtube"></i></a></li>
                    </ul>
                    <!-- /footer social -->
                </div>
            </div>
            <!-- /footer widget -->

            <!-- footer widget -->
            <div class="col-md-3 col-sm-6 col-xs-6">
                <div class="footer">
                    <h3 class="footer-header"><?php echo app('translator')->get('messages.Main Menu'); ?></h3>
                    <ul class="list-links">
                        <li><a href="<?php echo e(url('customer/home')); ?>"><?php echo app('translator')->get('messages.Home'); ?></a></li>
                        <li><a href="<?php echo e(url('customer/aboutus')); ?>"><?php echo app('translator')->get('messages.about us'); ?></a></li>
                        <li><a href="<?php echo e(url('customer/policy')); ?>"><?php echo app('translator')->get('messages.policy'); ?></a></li>
                        <li><a href="<?php echo e(url('customer/blog')); ?>"><?php echo app('translator')->get('messages.blog'); ?></a></li>
                        <li><a href="<?php echo e(url('customer/promotions')); ?>"><?php echo app('translator')->get('messages.offers'); ?></a></li>
                        <li><a href="<?php echo e(url('customer/contact_us')); ?>"><?php echo app('translator')->get('messages.Contact us'); ?></a></li>
                    </ul>
                </div>
            </div>
            <!-- /footer widget -->

            <div class="clearfix visible-sm visible-xs"></div>

            <!-- footer widget -->
            <div class="col-md-3 col-sm-6 col-xs-6">
                <div class="footer">
                    <h3 class="footer-header">Departments</h3>
                    <ul class="list-links">
                        <li><a href="<?php echo e(url('customer/products')); ?>">MAkeUp</a></li>
                        <li><a href="<?php echo e(url('customer/products')); ?>">Bags</a></li>
                        <li><a href="<?php echo e(url('customer/products')); ?>">Shoes</a></li>
                        <li><a href="<?php echo e(url('customer/products')); ?>">clothes</a></li>
                        <li><a href="<?php echo e(url('customer/products')); ?>">Dresses</a></li>
                    </ul>
                </div>
            </div>
            <!-- /footer widget -->

            <!-- footer widget -->
            <div class="col-md-3 col-sm-6 col-xs-6">
                <div class="footer">
                    <h3 class="footer-header"><?php echo app('translator')->get('messages.Keep in touch'); ?></h3>
                    <ul class="list-links keep">
                        <li><i class="fa fa-home"></i> Egypt, cairo</li>
                        <li><i class="fa fa-phone"></i><?php echo e($about->phone); ?></li>
                        <li><i class="fa fa-envelope"></i> <?php echo e($about->email); ?></li>
                    </ul>
                </div>
            </div>
            <!-- /footer widget -->

        </div>
        <!-- /row -->
        <hr>
        <!-- row -->
        <div class="row">
            <div class="col-md-8 col-md-offset-2 text-center">
                <!-- footer copyright -->
                <div class="footer-copyright">
                    <p><?php echo app('translator')->get('messages.© Copyright 2019 Nazan - Designed and Developed by'); ?> <a href="http://www.atiafco.com/" target="_blank"> Atiaf For Completely Solutions‏</a></p>
                </div>
                <!-- /footer copyright -->
            </div>
        </div>
        <!-- /row -->
    </div>
    <!-- /container -->
</footer>
<!-- /FOOTER -->

<!-- jQuery Plugins -->
<script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/slick.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/nouislider.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery.zoom.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/main.js')); ?>"></script>

</body>

</html>
<?php /**PATH C:\xampp\htdocs\nazan-v6last\nazan-v6\resources\views/customer/footer.blade.php ENDPATH**/ ?>