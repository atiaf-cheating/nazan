<?php $__env->startSection('content'); ?>
    <?php
        $language = App::getLocale();
        if(isset($parent_cat_id)){
            $parent_id = $parent_cat_id;
        }else{
            $parent_id = 0;
        }
    ?>
        <div class="row <?php if($language == 'ar'): ?> rtl <?php endif; ?>" style=" margin-top: 2%; margin-left: 2%;;padding:0;">
            <div class="col <?php if($language == 'ar'): ?> rtl <?php endif; ?>">
                <h2 class=" <?php if($language == 'ar'): ?> rtl <?php endif; ?>"><?php echo app('translator')->get('messages.products'); ?></h2>
            </div>

                <div class="col  <?php if($language == 'ar'): ?> rtl <?php endif; ?>" style="float:right;padding:0;">
                    <a class="btn btn-success <?php if($language == 'ar'): ?> rtl <?php endif; ?>" href="<?php echo e(url('products/create/')); ?>"> <?php echo app('translator')->get('messages.add new'); ?></a>
                </div>


        </div>

        <table class="table table-bordered products-table <?php if($language == 'ar'): ?> rtl <?php endif; ?>" style=" margin-top: 2%; margin-left: 2%;width:90%;" id="table">
            <thead>
            <tr class=" <?php if($language == 'ar'): ?> rtl <?php endif; ?>">
                <th class=" <?php if($language == 'ar'): ?> rtl <?php endif; ?>"><?php echo app('translator')->get('messages.arabic name'); ?></th>
                <th class=" <?php if($language == 'ar'): ?> rtl <?php endif; ?>"><?php echo app('translator')->get('messages.english name'); ?></th>
                <th class=" <?php if($language == 'ar'): ?> rtl <?php endif; ?>"><?php echo app('translator')->get('messages.description'); ?></th>
                <th class=" <?php if($language == 'ar'): ?> rtl <?php endif; ?>"><?php echo app('translator')->get('messages.merchant'); ?></th>
                <th class=" <?php if($language == 'ar'): ?> rtl <?php endif; ?>"><?php echo app('translator')->get('messages.brand'); ?></th>
                <th class=" <?php if($language == 'ar'): ?> rtl <?php endif; ?>"><?php echo app('translator')->get('messages.category'); ?></th>
                <th class=" <?php if($language == 'ar'): ?> rtl <?php endif; ?>"><?php echo app('translator')->get('messages.photo'); ?></th>
                <th class=" <?php if($language == 'ar'): ?> rtl <?php endif; ?>"><?php echo app('translator')->get('messages.order'); ?></th>
                <th class=" <?php if($language == 'ar'): ?> rtl <?php endif; ?>"><?php echo app('translator')->get('messages.actions'); ?></th>
            </tr>

            </thead>
            <tbody class=" <?php if($language == 'ar'): ?> rtl <?php endif; ?>">
            <?php if(count($products) == 0): ?>
            <?php endif; ?>
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                <tr class=" <?php if($language == 'ar'): ?> rtl <?php endif; ?>">
                    <th class=" <?php if($language == 'ar'): ?> rtl <?php endif; ?>"> <?php echo e($product->arabic_name); ?></th>
                    <th class=" <?php if($language == 'ar'): ?> rtl <?php endif; ?>"><?php echo e($product->english_name); ?></th>
                    <th class=" <?php if($language == 'ar'): ?> rtl <?php endif; ?>"><?php echo e($product->description); ?></th>
                    <th class=" <?php if($language == 'ar'): ?> rtl <?php endif; ?>"><?php echo e($product->merchant->arabic_name .'-'.$product->merchant->english_name); ?></th>
                    <th class=" <?php if($language == 'ar'): ?> rtl <?php endif; ?>"><?php echo e($product->brand->arabic_name .'-'.$product->brand->english_name); ?></th>
                    <th class=" <?php if($language == 'ar'): ?> rtl <?php endif; ?>"><?php echo e($product->category->arabic_name .'-'.$product->category->english_name); ?></th>
                    <th class=" <?php if($language == 'ar'): ?> rtl <?php endif; ?>" style="width: 6%; height: 6%;">
                        <img src=" <?php echo e(asset("images/products/".$product->image_url)); ?>" style="width: 100%;">
                    </th>
                    <th class=" <?php if($language == 'ar'): ?> rtl <?php endif; ?>"><?php echo e($product->order); ?></th>
                    <th class=" <?php if($language == 'ar'): ?> rtl <?php endif; ?>">


                        <a id="colors_sizes_btn" onclick="window.open(document.URL+ '/color-size/' + <?php echo e($product->id); ?>+ '/'+<?php echo e($product->cat_id); ?>, '_blank',
                            'location=yes,top=50,left=200,height=900,width=1500,scrollbars=yes,status=yes');"
                           class="btn btn-success <?php if($language == 'ar'): ?> rtl <?php endif; ?>" style="color:white;"><?php echo app('translator')->get('messages.add color/size details'); ?></a>
                        <a href="<?php echo e(url('products/edit/'.$product->id)); ?>" class="btn btn-info <?php if($language == 'ar'): ?> rtl <?php endif; ?>"><?php echo app('translator')->get('messages.edit'); ?></a>
                        <a href="<?php echo e(url('products/activate/'.$product->id)); ?>" class="btn btn-warning <?php if($language == 'ar'): ?> rtl <?php endif; ?>"><?php if($product->active == 0): ?> <?php echo app('translator')->get('messages.activate'); ?> <?php else: ?> <?php echo app('translator')->get('messages.deactivate'); ?> <?php endif; ?></a>
                        <a href="<?php echo e(url('products/delete/'.$product->id)); ?>" onclick="return confirm('Are you sure?')" class="btn btn-danger <?php if($language == 'ar'): ?> rtl <?php endif; ?>"><?php echo app('translator')->get('messages.delete'); ?></a>
                    </th>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <?php echo e($products->links()); ?>

    <script>
        document.getElementById("colors_sizes_btn").addEventListener("click", function(event){
            event.preventDefault();
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('categories.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nazan-v6last\nazan-v6\resources\views/products/index.blade.php ENDPATH**/ ?>