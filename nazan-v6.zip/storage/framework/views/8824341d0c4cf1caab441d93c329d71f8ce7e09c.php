<?php $__env->startSection('content'); ?>
    <?php
        $language = App::getLocale();
        if(isset($parent_cat_id)){
            $parent_id = $parent_cat_id;
        }else{
            $parent_id = 0;
        }
    ?>
    <div class="row <?php if($language == 'ar'): ?> rtl <?php endif; ?>" style=" margin-top: 2%; margin-left: 2%;;padding:0;">
        <div class="col <?php if($language == 'ar'): ?> rtl <?php endif; ?>">
            <h2 class=" <?php if($language == 'ar'): ?> rtl <?php endif; ?>"><?php echo app('translator')->get('messages.settings'); ?></h2>
        </div>
    </div>
    <form method="post" action="<?php echo e(route('settings.store')); ?>">
        <?php echo csrf_field(); ?>
        <div class="form-group row">
            <label for="colFormLabel" class="col-sm-2 col-form-label">Phone</label>
            <div class="col-sm-10">
                <input type="text" name="phone" class="form-control form-control-sm" id="colFormLabelSm" value="<?php echo e($settings->phone); ?>">
            </div>
        </div>
        <div class="form-group row">
            <label for="colFormLabel" class="col-sm-2 col-form-label">Email</label>
            <div class="col-sm-10">
                <input type="email"  name="email"  class="form-control" id="colFormLabel" value="<?php echo e($settings->email); ?>">
            </div>
        </div>
        <div class="form-group row">
            <label for="colFormLabelLg" class="col-sm-2 col-form-label col-form-label-lg">Facebook</label>
            <div class="col-sm-10">
                <input type="link"  name="facebook_url"  class="form-control form-control-lg" id="colFormLabelLg"value="<?php echo e($settings->facebook_url); ?>">
            </div>
        </div>
        <div class="form-group row">
            <label for="colFormLabelLg" class="col-sm-2 col-form-label col-form-label-lg">twitter</label>
            <div class="col-sm-10">
                <input type="link"  name="twitter_url"  class="form-control form-control-lg" id="colFormLabelLg"value="<?php echo e($settings->twitter_url); ?>">
            </div>
        </div>
        <div class="form-group row">
            <label for="colFormLabelLg" class="col-sm-2 col-form-label col-form-label-lg">instagram</label>
            <div class="col-sm-10">
                <input type="link"  name="instagram_url"  class="form-control form-control-lg" id="colFormLabelLg"value="<?php echo e($settings->instagram_url); ?>">
            </div>
        </div>
        <br>
        <input type="submit" class="btn btn-success">
    </form>
    <script>


    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('categories.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nazan-v6last\nazan-v6\resources\views/settings.blade.php ENDPATH**/ ?>