<?php $__env->startSection('content'); ?>
    

    <?php if(Session::has('message')): ?>
        <p class="alert <?php echo e(Session::get('alert-class', 'alert-info')); ?>"><?php echo e(Session::get('message')); ?></p>
    <?php endif; ?>
    <!-- NAVIGATION -->
    <div id="navigation">
        <!-- container -->
        <div class="container">
            <a class="toggleMenu" href="#"><i class="fa fa-bars"></i></a>
            <ul class="nav">
                <li><a class="first" href="<?php echo e(url('/customer/home')); ?>"><?php echo app('translator')->get('messages.Home'); ?></a></li>
                <li><a href="<?php echo e(url('/customer/aboutus')); ?>"><?php echo app('translator')->get('messages.about us'); ?></a></li>
                <li>
                    <a href="#"><?php echo app('translator')->get('messages.categories'); ?></a>
                    <ul>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                                <a href="<?php echo e(url('/customer/products/'.$category->id)); ?>"><?php echo e($category->arabic_name); ?>- <?php echo e($category->english_name); ?></a>
                                <?php if($category->subCategories): ?>
                                    <ul>
                                        <?php $__currentLoopData = $category->subCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li>
                                                <a href="<?php echo e(url('/customer/products/'.$subCategory->id)); ?>"><?php echo e($subCategory->arabic_name); ?>-<?php echo e($subCategory->english_name); ?></a>
                                                <?php if($subCategory->subCategories): ?>
                                                    <ul>
                                                        <?php $__currentLoopData = $subCategory->subCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <li>
                                                                <a href="<?php echo e(url('/customer/products/'.$subCategory->id)); ?>"><?php echo e($subCategory->arabic_name); ?>-<?php echo e($subCategory->english_name); ?></a>
                                                            </li>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </ul>
                                                <?php endif; ?>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                <?php endif; ?>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                        
                        
                        
                        
                        
                        
                        
                    </ul>
                </li>
                <li><a href="<?php echo e(url('customer/promotions')); ?>"><?php echo app('translator')->get('messages.offers'); ?></a></li>
                <li><a href="<?php echo e(url('/customer/policy')); ?>"><?php echo app('translator')->get('messages.policy'); ?></a></li>
                <li><a href="<?php echo e(url('/customer/contact_us')); ?>"><?php echo app('translator')->get('messages.Contact us'); ?></a></li>
            </ul>
        </div>
        <!-- /container -->
    </div>
    <!-- /NAVIGATION -->

    <!-- HOME -->
    <div id="home">
        <!-- container -->
        <div class="container">
            <!-- home wrap -->
            <div class="home-wrap">
                <!-- home slick -->
                <div id="home-slick">
                    <!-- banner -->
                    <?php $__currentLoopData = $gallery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $galleryItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="banner banner-1">
                            <img src="<?php echo e(asset('images/galleries/'.$galleryItem->large_image)); ?>" alt="">
                            <div class="banner-caption">
                                <h1 class="white-color"><?php echo app('translator')->get('messages.New Product Collection'); ?></h1>
                                <a href="<?php echo e(url('customer/products/'.$products[0]->cat_id)); ?>" class="btn primary-btn"><?php echo app('translator')->get('messages.Shop Now'); ?></a>
                            </div>
                        </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <!-- /banner -->
                </div>
                <!-- /home slick -->
            </div>
            <!-- /home wrap -->
        </div>
        <!-- /container -->
    </div>
    <!-- /HOME -->

    <!-- section -->
    <div class="section collection">
        <!-- container -->
        <div class="container">
            <!-- row -->
            <div class="row">
                <!-- banner -->
                

                <?php $__currentLoopData = $gallery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $galleryItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-4 col-sm-6">
                        <a class="banner banner-1" href="<?php echo e(url('customer/products/'.$products[0]->cat_id)); ?>">
                            <img src="<?php echo e(asset('images/galleries/'.$galleryItem->phone_image)); ?>" alt=""/>
                            <div class="banner-caption text-center">
                                <h2 class="white-color"><?php echo app('translator')->get('messages.new collection'); ?></h2>
                            </div>
                        </a>
                    </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <!-- /banner -->


            </div>
            <!-- /row -->
        </div>
        <!-- /container -->
    </div>
    <!-- /section -->

    <!-- section -->
    <div class="section side">
        <!-- container -->
        <div class="container">
            <div class="col-md-12">
                <div class="section">
                    <div class="row">
                        <div class="col-md-9 col-sm-12">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="best-seller">
                                        <!-- section-title -->
                                        <div class="col-md-12">
                                            <div class="section-title">
                                                <h2 class="title"><?php echo app('translator')->get('messages.Best sellers'); ?></h2>
                                                <div class="pull-right">
                                                    <div class="product-slick-dots-1 custom-dots"></div>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- /section-title -->
                                        <!-- Product Slick -->
                                        <div class="col-md-12">
                                            <div class="row">
                                                <div id="product-slick-1" class="product-slick">
                                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if(isset($product->colors[0]) && isset($product->colors[0]->sizes[0])): ?>


                                                        <?php if(in_array($product->id ,$bestSellers->toArray())): ?>
                                                            <!-- Product Single -->
                                                                <div class="col-md-4 col-sm-6 col-xs-6 single-product-float">
                                                                    <div class="product product-single">
                                                                        <div class="product-thumb">
                                                                            <div class="product-label">
                                                                                <span><?php echo app('translator')->get('messages.new'); ?></span>
                                                                                <span class="sale">-<?php if($product->colors[0]->sizes[0]->discount != null): ?><?php echo e($product->colors[0]->sizes[0]->discount); ?><?php elseif($product->colors[0]->sizes[0]->discount == null): ?>0 <?php endif; ?>%</span>
                                                                            </div>
                                                                            <a class="main-btn quick-view" href="<?php echo e(url('/customer/product/details/'.$product->id)); ?>"><i class="fa fa-eye"></i> <?php echo app('translator')->get('messages.details'); ?></a>
                                                                            <img src="<?php echo e(asset('images/products/'.$product->image_url)); ?>" alt="">
                                                                        </div>
                                                                        <div class="product-body">
                                                                            <h3 class="product-price">
                                                                                <?php if($product->colors[0]->sizes[0]->discount == null): ?> $<?php echo e($product->colors[0]->sizes[0]->price); ?>

                                                                                <?php elseif($product->colors[0]->sizes[0]->discount != null): ?>
                                                                                    $<?php echo e($product->colors[0]->sizes[0]->price - $product->colors[0]->sizes[0]->price *$product->colors[0]->sizes[0]->discount /100); ?>

                                                                                <?php endif; ?>
                                                                                <del class="product-old-price"><?php if($product->colors[0]->sizes[0]->discount == null): ?>
                                                                                    <?php elseif($product->colors[0]->sizes[0]->discount != null): ?>
                                                                                        $<?php echo e($product->colors[0]->sizes[0]->price); ?>

                                                                                    <?php endif; ?>
                                                                                </del>
                                                                            </h3>
                                                                            <h2 class="product-name"><a href="<?php echo e(url('/customer/product/details/'.$product->id)); ?>"><?php echo e($product->arabic_name); ?> - <?php echo e($product->english_name); ?> </a></h2>
                                                                            <div class="product-btns row" style="display:flex;">
                                                                                <?php if($product->is_favourite == false): ?>
                                                                                    <a class="main-btn icon-btn" href="<?php echo e(url('/customer/product/add_to_favourites/'.$product->id)); ?>" data-target="#exampleModal"><i class="fa fa-heart-o"></i></a>
                                                                                <?php elseif($product->is_favourite == true): ?>
                                                                                    <a class="main-btn icon-btn" href="<?php echo e(url('/customer/product/remove_favourites/'.$product->id)); ?>" data-target="#exampleModal"><i class="fa fa-heart"></i></a>
                                                                                <?php endif; ?>
                                                                                <form action="<?php echo e(url('customer/add_to_cart')); ?>" method="post" class="col" >
                                                                                    <?php echo csrf_field(); ?>
                                                                                    <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
                                                                                    <input type="hidden" name="arabic_name" value="<?php echo e($product->arabic_name); ?>">
                                                                                    <input type="hidden" name="english_name" value="<?php echo e($product->english_name); ?>">
                                                                                    <input type="hidden" name="description" value="<?php echo e($product->description); ?>">
                                                                                    <input type="hidden" name="image_url" value="<?php echo e($product->image_url); ?>">
                                                                                    <input type="hidden" name="cat_id" value="<?php echo e($product->cat_id); ?>">
                                                                                    <input type="hidden" name="merchant_id" value="<?php echo e($product->merchant_id); ?>">
                                                                                    <input type="hidden" name="brand_id" value="<?php echo e($product->brand_id); ?>">
                                                                                    <input type="hidden" name="color_id" value="<?php echo e($product->colors[0]->id); ?>">
                                                                                    <input type="hidden" name="size_id" value="<?php echo e($product->colors[0]->sizes[0]->id); ?>">
                                                                                    <input type="hidden" name="price" value="<?php echo e($product->colors[0]->sizes[0]->price); ?>">
                                                                                    <input type="hidden" name="discount" value="<?php echo e($product->colors[0]->sizes[0]->discount); ?>">
                                                                                    <button type="submit"  class="primary-btn add-to-cart"><i class="fa fa-shopping-cart"></i> <?php echo app('translator')->get('messages.Add to Cart'); ?></button>

                                                                                </form>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>

                                                                <div class="clearfix visible-sm visible-xs"></div>
                                                        <?php endif; ?>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <!-- /Product Single -->

                                                </div>
                                            </div>
                                        </div>
                                        <!-- /Product Slick -->
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="trending">
                                        <!-- section-title -->
                                        <div class="col-md-12">
                                            <div class="section-title">
                                                <h2 class="title"><?php echo app('translator')->get('messages.trending'); ?></h2>
                                                <div class="pull-right">
                                                    <div class="product-slick-dots-2 custom-dots"></div>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- /section-title -->

                                        <!-- Product Slick -->
                                        <div class="col-md-12">
                                            <div class="row">
                                                <div id="product-slick-2" class="product-slick">
                                                    <!-- Product Single -->

                                                <?php for($i=0 ; $i<5 ;$i++): ?>
                                                    <?php if(isset($products[$i]->colors[0]) && isset($products[$i]->colors[0]->sizes[0])): ?>

                                                        <!-- Product Single -->
                                                            <div class="col-md-4 col-sm-6 col-xs-6 single-product-float">
                                                                <div class="product product-single">
                                                                    <div class="product-thumb">
                                                                        <div class="product-label">
                                                                            <span><?php echo app('translator')->get('messages.new'); ?></span>
                                                                            <span class="sale">-<?php if($products[$i]->colors[0]->sizes[0]->discount != null): ?><?php echo e($products[$i]->colors[0]->sizes[0]->discount); ?><?php elseif($products[$i]->colors[0]->sizes[0]->discount == null): ?>0 <?php endif; ?>%</span>
                                                                        </div>
                                                                        <a class="main-btn quick-view" href="<?php echo e(url('/customer/product/details/'.$products[$i]->id)); ?>"><i class="fa fa-eye"></i> <?php echo app('translator')->get('messages.details'); ?></a>
                                                                        <img src="<?php echo e(asset('images/products/'.$products[$i]->image_url)); ?>" alt="">
                                                                    </div>
                                                                    <div class="product-body">
                                                                        <h3 class="product-price">
                                                                            <?php if($products[$i]->colors[0]->sizes[0]->discount == null): ?> $<?php echo e($products[$i]->colors[0]->sizes[0]->price); ?>

                                                                            <?php elseif($products[$i]->colors[0]->sizes[0]->discount != null): ?>
                                                                                $<?php echo e($products[$i]->colors[0]->sizes[0]->price - $products[$i]->colors[0]->sizes[0]->price *$products[$i]->colors[0]->sizes[0]->discount /100); ?>

                                                                            <?php endif; ?>
                                                                            <del class="product-old-price"><?php if($products[$i]->colors[0]->sizes[0]->discount == null): ?>
                                                                                <?php elseif($products[$i]->colors[0]->sizes[0]->discount != null): ?>
                                                                                    $<?php echo e($products[$i]->colors[0]->sizes[0]->price); ?>

                                                                                <?php endif; ?>
                                                                            </del>

                                                                        </h3>
                                                                        <h2 class="product-name"><a href="<?php echo e(url('/customer/product/details/'.$products[$i]->id)); ?>"><?php echo e($products[$i]->arabic_name); ?> - <?php echo e($products[$i]->english_name); ?> </a></h2>
                                                                        <div class="product-btns row" style="display: flex;">

                                                                        <?php if($product->is_favourite == false): ?>
                                                                                <a class="main-btn icon-btn" href="<?php echo e(url('/customer/product/add_to_favourites/'.$products[$i]->id)); ?>" data-target="#exampleModal"><i class="fa fa-heart-o"></i></a>
                                                                            <?php elseif($product->is_favourite == true): ?>
                                                                                <a class="main-btn icon-btn" href="<?php echo e(url('/customer/product/remove_favourites/'.$products[$i]->id)); ?>" data-target="#exampleModal"><i class="fa fa-heart"></i></a>
                                                                            <?php endif; ?>
                                                                            <form action="<?php echo e(url('customer/add_to_cart')); ?>" method="post" class="col">
                                                                                <?php echo csrf_field(); ?>
                                                                                <input type="hidden" name="product_id" value="<?php echo e($products[$i]->id); ?>">
                                                                                <input type="hidden" name="arabic_name" value="<?php echo e($products[$i]->arabic_name); ?>">
                                                                                <input type="hidden" name="english_name" value="<?php echo e($products[$i]->english_name); ?>">

                                                                                <input type="hidden" name="description" value="<?php echo e($products[$i]->description); ?>">
                                                                                <input type="hidden" name="image_url" value="<?php echo e($products[$i]->image_url); ?>">
                                                                                <input type="hidden" name="cat_id" value="<?php echo e($products[$i]->cat_id); ?>">
                                                                                <input type="hidden" name="merchant_id" value="<?php echo e($products[$i]->merchant_id); ?>">
                                                                                <input type="hidden" name="brand_id" value="<?php echo e($products[$i]->brand_id); ?>">

                                                                                <input type="hidden" name="color_id" value="<?php echo e($products[$i]->colors[0]->id); ?>">
                                                                                <input type="hidden" name="size_id" value="<?php echo e($products[$i]->colors[0]->sizes[0]->id); ?>">
                                                                                <input type="hidden" name="price" value="<?php echo e($products[$i]->colors[0]->sizes[0]->price); ?>">
                                                                                <input type="hidden" name="discount" value="<?php echo e($products[$i]->colors[0]->sizes[0]->discount); ?>">

                                                                                <button type="submit"  class="primary-btn add-to-cart"><i class="fa fa-shopping-cart"></i> <?php echo app('translator')->get('messages.Add to Cart'); ?></button>

                                                                            </form>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>

                                                            <div class="clearfix visible-sm visible-xs"></div>
                                                    <?php endif; ?>
                                                <?php endfor; ?>
                                                <!-- /Product Single -->

                                                </div>
                                            </div>
                                        </div>
                                        <!-- /Product Slick -->
                                    </div>
                                </div>


                                <div class="col-md-12">
                                    <div class="information">
                                        <!-- section-title -->
                                        <div class="col-md-12">
                                            <div class="section-title">
                                                <h2 class="title"><?php echo app('translator')->get('messages.Insider Information'); ?></h2>
                                            </div>
                                        </div>
                                        <!-- /section-title -->

                                        <!-- Product Slick -->
                                        <div class="col-md-12">
                                            <div class="row">

                                                <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <div class="info-det">
                                                        <div class="col-md-4">
                                                            <img src="<?php echo e(asset('images/articles/'.$article->image_url)); ?>" alt="" class="img-responsive" >
                                                        </div>
                                                        <div class="col-md-8">
                                                            <h3><?php echo e($article->title); ?></h3>
                                                            <p>
                                                                <?php echo e($article->body); ?>

                                                            </p>
                                                            <a href="<?php echo e(url('customer/blog_details/'.$article->id)); ?>" class="more"><?php echo app('translator')->get('messages.Read More'); ?></a>
                                                        </div>
                                                    </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>

                        <div class="col-md-3 col-sm-12">
                            <div class="row">
                                <div class="banner banner-2">
                                    <img src="<?php echo e(asset('img/banner15.jpg')); ?>" alt="" class="img-responsive">
                                    <div class="banner-caption">
                                        <h2 class="white-color"><?php echo app('translator')->get('messages.new collection'); ?><br></h2>
                                        <a href="<?php echo e(url('customer/products/'.$products[0]->cat_id)); ?>" class="btn primary-btn"><?php echo app('translator')->get('messages.Shop Now'); ?></a>

                                    </div>
                                </div>
                                <div class="banner banner-2">
                                    <img src="<?php echo e(asset('img/banner15.jpg')); ?>" alt="" class="img-responsive">
                                    <div class="banner-caption">
                                        <h2 class="white-color"><?php echo app('translator')->get('messages.new collection'); ?><br></h2>
                                        <a href="<?php echo e(url('customer/products/'.$products[0]->cat_id)); ?>" class="btn primary-btn"><?php echo app('translator')->get('messages.Shop Now'); ?></a>
                                    </div>
                                </div>
                                <div class="banner banner-2">
                                    <img src="<?php echo e(asset('img/banner15.jpg')); ?>" alt="" class="img-responsive">
                                    <div class="banner-caption">
                                        <h2 class="white-color"><?php echo app('translator')->get('messages.new collection'); ?><br></h2>
                                        <a href="<?php echo e(url('customer/products/'.$products[0]->cat_id)); ?>" class="btn primary-btn"><?php echo app('translator')->get('messages.Shop Now'); ?></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- /container -->
    </div>
    <!-- /section -->

    <!-- section -->
    <div class="section">
        <!-- container -->
        <div class="container">
            <!-- row -->
            <div class="row">
                <div class="col-md-12">
                    <div class="customers">
                        <!-- section-title -->
                        <div class="col-md-12">
                            <div class="section-title">
                                <h2 class="title"><?php echo app('translator')->get('messages.What our customers are saying'); ?></h2>
                                <div class="pull-right">
                                    <div class="product-slick-dots-3 custom-dots"></div>
                                </div>
                            </div>
                        </div>
                        <!-- /section-title -->

                        <!-- Product Slick -->
                        <div class="col-md-12">
                            <div class="row">
                                <div id="product-slick-3" class="product-slick">
                                    <!-- Product Single -->
                                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if(isset($product->colors[0]) && isset($product->colors[0]->sizes[0])): ?>
                                            <div class="product product-single">
                                                <div class="product-thumb">
                                                    <div class="product-label">
                                                        <span><?php echo app('translator')->get('messages.new'); ?></span>
                                                        <span class="sale">-<?php if($product->colors[0]->sizes[0]->discount != null): ?><?php echo e($product->colors[0]->sizes[0]->discount); ?><?php elseif($product->colors[0]->sizes[0]->discount == null): ?>0 <?php endif; ?>%</span>
                                                    </div>
                                                    <a class="main-btn quick-view" href="<?php echo e(url('/customer/product/details/'.$product->id)); ?>"><i class="fa fa-eye"></i> <?php echo app('translator')->get('messages.details'); ?></a>
                                                    <img src="<?php echo e(asset('images/products/'.$product->image_url)); ?>" alt="">
                                                </div>
                                                <div class="product-body">
                                                    <h3 class="product-price">
                                                        <?php if($product->colors[0]->sizes[0]->discount == null): ?> $<?php echo e($product->colors[0]->sizes[0]->price); ?>

                                                        <?php elseif($product->colors[0]->sizes[0]->discount != null): ?>
                                                            $<?php echo e($product->colors[0]->sizes[0]->price - $product->colors[0]->sizes[0]->price *$product->colors[0]->sizes[0]->discount /100); ?>

                                                        <?php endif; ?>
                                                        <del class="product-old-price"><?php if($product->colors[0]->sizes[0]->discount == null): ?>
                                                            <?php elseif($product->colors[0]->sizes[0]->discount != null): ?>
                                                                $<?php echo e($product->colors[0]->sizes[0]->price); ?>

                                                            <?php endif; ?>
                                                        </del>
                                                    </h3>
                                                    <h2 class="product-name"><a href="<?php echo e(url('/customer/product/details/'.$product->id)); ?>"><?php echo e($product->arabic_name); ?> - <?php echo e($product->english_name); ?> </a></h2>
                                                    <div class="rate">
                                                        <div class="product-rating">
                                                            <?php for($i = 0 ; $i < $product->total_reviews ; $i++): ?>
                                                                <i class="fa fa-star"></i>
                                                            <?php endfor; ?>
                                                            <?php for($i = 0 ; $i < 5- $product->total_reviews ; $i++): ?>
                                                                <i class="fa fa-star-o empty"></i>
                                                            <?php endfor; ?>
                                                        </div>
                                                    </div>
                                                    <?php if(count($product->reviews) >0): ?>
                                                        <p class="reviewQuote"><?php echo e($product->reviews[0]->comment); ?></p>
                                                    <?php endif; ?>
                                                    <div class="product-btns row" style="display: flex;">
                                                        <?php if($product->is_favourite == false): ?>
                                                            <a class="main-btn icon-btn col" href="<?php echo e(url('/customer/product/add_to_favourites/'.$product->id)); ?>" data-target="#exampleModal"><i class="fa fa-heart-o"></i></a>
                                                        <?php elseif($product->is_favourite == true): ?>
                                                            <a class="main-btn icon-btn col" href="<?php echo e(url('/customer/product/remove_favourites/'.$product->id)); ?>" data-target="#exampleModal"><i class="fa fa-heart"></i></a>
                                                        <?php endif; ?>
                                                        <form action="<?php echo e(url('customer/add_to_cart')); ?>" method="post" class="col">
                                                            <?php echo csrf_field(); ?>
                                                            <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
                                                            <input type="hidden" name="arabic_name" value="<?php echo e($product->arabic_name); ?>">
                                                            <input type="hidden" name="english_name" value="<?php echo e($product->english_name); ?>">
                                                            <input type="hidden" name="description" value="<?php echo e($product->description); ?>">
                                                            <input type="hidden" name="image_url" value="<?php echo e($product->image_url); ?>">
                                                            <input type="hidden" name="cat_id" value="<?php echo e($product->cat_id); ?>">
                                                            <input type="hidden" name="merchant_id" value="<?php echo e($product->merchant_id); ?>">
                                                            <input type="hidden" name="brand_id" value="<?php echo e($product->brand_id); ?>">
                                                            <input type="hidden" name="color_id" value="<?php echo e($product->colors[0]->id); ?>">
                                                            <input type="hidden" name="size_id" value="<?php echo e($product->colors[0]->sizes[0]->id); ?>">
                                                            <input type="hidden" name="price" value="<?php echo e($product->colors[0]->sizes[0]->price); ?>">
                                                            <input type="hidden" name="discount" value="<?php echo e($product->colors[0]->sizes[0]->discount); ?>">
                                                            <button type="submit"  class="primary-btn add-to-cart"><i class="fa fa-shopping-cart"></i> <?php echo app('translator')->get('messages.Add to Cart'); ?></button>

                                                        </form>
                                                    </div>

                                                </div>
                                            </div>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <!-- /Product Single -->

                                </div>
                            </div>
                        </div>
                        <!-- /Product Slick -->
                    </div>
                </div>
            </div>
            <!-- /row -->
        </div>
        <!-- /container -->
    </div>
    <!-- /section -->

    <!-- section -->
    <div class="section">
        <!-- container -->
        <div class="container">
            <!-- row -->
            <div class="row">
                <div class="col-md-12">
                    <div class="sponsers">
                        <!-- section-title -->
                        <div class="col-md-12">
                            <div class="section-title">
                                <h2 class="title"><?php echo app('translator')->get('messages.Brands'); ?></h2>
                                <div class="pull-right">
                                    <div class="product-slick-dots-4 custom-dots"></div>
                                </div>
                            </div>
                        </div>
                        <!-- /section-title -->

                        <!-- Product Slick -->
                        <div class="col-md-12">
                            <div class="row">
                                <div id="product-slick-4" class="product-slick">
                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <!-- Product Single -->
                                        <div class="sponsers-single">
                                            <img src="<?php echo e(asset('images/brands/'.$product->brand->image_url)); ?>" alt="" >
                                        </div>
                                        <!-- /Product Single -->
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                        <!-- /Product Slick -->
                    </div>
                </div>
            </div>
            <!-- /row -->
        </div>
        <!-- /container -->
    </div>
    <!-- /section -->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('customer.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nazan-v6last\nazan-v6\resources\views/customer/index.blade.php ENDPATH**/ ?>