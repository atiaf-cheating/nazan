<?php $__env->startSection('content'); ?>
    <?php
        $language = App::getLocale();
    ?>
        <div class="row <?php if($language == 'ar'): ?> rtl <?php endif; ?>" style=" margin-top: 2%; margin-left: 2%;;padding:0;">
            <div class="col <?php if($language == 'ar'): ?> rtl <?php endif; ?>">
                <h2 class=" <?php if($language == 'ar'): ?> rtl <?php endif; ?>"><?php echo app('translator')->get('messages.promotions'); ?></h2>
            </div>
            <div class="col  <?php if($language == 'ar'): ?> rtl <?php endif; ?>" style="float:right;padding:0;">
                <a class="btn btn-success <?php if($language == 'ar'): ?> rtl <?php endif; ?>" href="<?php echo e(url('promotions/create')); ?>"> <?php echo app('translator')->get('messages.add new'); ?></a>
            </div>

        </div>

        <table class="table table-bordered categories-table <?php if($language == 'ar'): ?> rtl <?php endif; ?>" style=" margin-top: 2%; margin-left: 2%;width:90%;" id="table">
            <thead>
            <tr class=" <?php if($language == 'ar'): ?> rtl <?php endif; ?>">
                <th class=" <?php if($language == 'ar'): ?> rtl <?php endif; ?>"><?php echo app('translator')->get('messages.product'); ?></th>
                <th class=" <?php if($language == 'ar'): ?> rtl <?php endif; ?>"><?php echo app('translator')->get('messages.photo'); ?></th>
                <th class=" <?php if($language == 'ar'): ?> rtl <?php endif; ?>"><?php echo app('translator')->get('messages.days of expiry'); ?></th>
                <th class=" <?php if($language == 'ar'): ?> rtl <?php endif; ?>"><?php echo app('translator')->get('messages.actions'); ?></th>
            </tr>

            </thead>
            <tbody class=" <?php if($language == 'ar'): ?> rtl <?php endif; ?>">
            <?php $__currentLoopData = $promotions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $promotion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($promotion->product != null): ?>

                    <tr class=" <?php if($language == 'ar'): ?> rtl <?php endif; ?>">
                        <th class=" <?php if($language == 'ar'): ?> rtl <?php endif; ?>">
                                <?php echo e($promotion->product['english_name']); ?>

                        </th>
                        <th class=" <?php if($language == 'ar'): ?> rtl <?php endif; ?>" style="width: 6%; height: 6%;">
                            <img src=" <?php echo e(asset("images/promotions/".$promotion->image_url)); ?>" style="width: 100%;">
                        </th>
                        <th class=" <?php if($language == 'ar'): ?> rtl <?php endif; ?>" > <?php echo e($promotion->expiry_date); ?></th>
                        <th class=" <?php if($language == 'ar'): ?> rtl <?php endif; ?>">
                            <a href="<?php echo e(url('promotions/edit/'.$promotion->id)); ?>" class="btn btn-info <?php if($language == 'ar'): ?> rtl <?php endif; ?>"><?php echo app('translator')->get('messages.edit'); ?></a>
                            <a href="<?php echo e(url('promotions/activate/'.$promotion->id)); ?>" onclick="return confirm('Are you sure?')" class="btn btn-warning <?php if($language == 'ar'): ?> rtl <?php endif; ?>"><?php if($promotion->active == 0): ?> <?php echo app('translator')->get('messages.activate'); ?> <?php else: ?> <?php echo app('translator')->get('messages.deactivate'); ?> <?php endif; ?></a>
                            <a href="<?php echo e(url('promotions/delete/'.$promotion->id)); ?>" onclick="return confirm('Are you sure?')" class="btn btn-danger <?php if($language == 'ar'): ?> rtl <?php endif; ?>"><?php echo app('translator')->get('messages.delete'); ?></a>
                        </th>
                    </tr>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <?php echo e($promotions->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('categories.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nazan-v6last\nazan-v6\resources\views/promotions/index.blade.php ENDPATH**/ ?>