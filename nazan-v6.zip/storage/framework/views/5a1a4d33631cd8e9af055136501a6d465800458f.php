<?php echo $__env->make('customer.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php
    $language = App::getLocale();
?>
<?php echo $__env->yieldContent('content'); ?>
<?php echo $__env->make('customer.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\nazan-v6last\nazan-v6\resources\views/customer/layout.blade.php ENDPATH**/ ?>